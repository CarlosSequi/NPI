package com.example.samuel.aplicacionmuseo;

import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.IsoDep;

import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.Arrays;

/**
 * Callback class, invoked when an NFC card is scanned while the device is running in reader mode.
 *
 * Reader mode can be invoked by calling NfcAdapter
 */
public class card_reader implements NfcAdapter.ReaderCallback {
    private static final String TAG = "LoyaltyCardReader";

    // Weak reference to prevent retain loop. mAccountCallback is responsible for exiting
    // foreground mode before it becomes invalid (e.g. during onPause() or onStop()).
    private WeakReference<AccountCallback> mAccountCallback;
    private MifareUltralightTagTester tagManager;


    public interface AccountCallback {
        public void onAccountReceived(String account);
    }

    public card_reader(AccountCallback accountCallback) {
        mAccountCallback = new WeakReference<AccountCallback>(accountCallback);
        tagManager = new MifareUltralightTagTester();
    }

    /**
     * Callback when a new tag is discovered by the system.
     *
     * <p>Communication with the card should take place here.
     *
     * @param tag Discovered tag
     */
    @Override
    public void onTagDiscovered(Tag tag) {
        Log.i(TAG, "New tag discovered");
        String indiceEtiqueta = tagManager.readTag(tag);
        //ImageView imagen = (ImageView) gestorVista.findViewById(R.id.imageView3);

        if(indiceEtiqueta.charAt(0) == '1')
        {
            Log.i(TAG, "IDENTIFICADA LA PRIMERA ETIQUETA");
            ////imagen.setImageResource(R.drawable.hierbas_provenzales;

        }
        else if (indiceEtiqueta.charAt(0) == '2')
        {
            Log.i(TAG, "IDENTIFICADA LA SEGUNDA ETIQUETA");
            //imagen.setImageResource(R.drawable.jcss);
        }
    }


}