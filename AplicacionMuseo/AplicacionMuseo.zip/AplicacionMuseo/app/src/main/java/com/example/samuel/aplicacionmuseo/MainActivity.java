package com.example.samuel.aplicacionmuseo;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.nfc.NdefMessage;
import android.nfc.NfcAdapter;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.location.LocationManager;
import android.location.LocationListener;
import android.location.Location;
import android.content.Context;
import android.support.v4.content.*;
import android.support.v7.app.AlertDialog;
import android.content.DialogInterface;
import java.util.ArrayList;
import android.nfc.Tag;

import android.nfc.tech.MifareUltralight;





public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, NfcAdapter.ReaderCallback {



    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    TextView textIntro;
    //Acquire a reference to the system Location Manager
    LocationManager locationManager;
    // Define a listener that responds to location updates
    LocationListener locationListener;

    private ArrayList<Double> latitude_range;
    private ArrayList<Double> longitude_range;

    //Para cambiar entre diferentes fragmentos de nuestra aplicación:
    FragmentTransaction fragment_transaction;

    MifareUltralightTagTester tag_reader = new MifareUltralightTagTester();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        latitude_range = new ArrayList<Double>();
        longitude_range = new ArrayList<Double>();

        latitude_range.add(35.0);
        latitude_range.add(40.0);

        longitude_range.add(-4.0);
        longitude_range.add(-2.0);




        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);



        locationListener = new LocationListener() {
            public void onLocationChanged(Location location) {
                // Called when a new location is found by the network location provider.
                checkLocation(location);
            }

            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            public void onProviderEnabled(String provider) {
            }

            public void onProviderDisabled(String provider) {
            }
        };





        checkLocationPermission();
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListener);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);



        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();


        //Inicialmente bloqueamos el acceso a la navegación:
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        Menu menuNav=navigationView.getMenu();
        menuNav.findItem(R.id.home_bar).setEnabled(false);
        menuNav.findItem(R.id.map_bar).setEnabled(false);
        menuNav.findItem(R.id.nfc_bar).setEnabled(true);
        menuNav.findItem(R.id.voice_bar).setEnabled(false);
        textIntro = (TextView)(findViewById(R.id.textIntro));
        textIntro.setText("Accediendo al museo...");

        //Aniadimos el fragmento de Home:
        fragment_transaction = getSupportFragmentManager().beginTransaction();
        fragment_transaction.add(R.id.main_container, new HomeFragment());
        navigationView.setNavigationItemSelectedListener(this);
        getSupportActionBar().setTitle("Home");
        fragment_transaction.commit();
    }

    @Override
    public void onTagDiscovered(Tag tag) {

        Log.i("hello", "New tag discovered");
    }

    protected void checkLocation(Location location) {

        textIntro = (TextView)(findViewById(R.id.textIntro));

        //Acdedemos a la barra de navegación
        NavigationView navigationView= findViewById(R.id.nav_view);
        Menu menuNav=navigationView.getMenu();


        //Si no nos encontramos dentro del museo impedimos que se
        // utilice la aplicación:

        if(location.getLatitude() > latitude_range.get(0) &&
                location.getLatitude() < latitude_range.get(1) &&
                location.getLatitude() > longitude_range.get(0) &&
                location.getLatitude() < longitude_range.get(1) ){


            menuNav.findItem(R.id.home_bar).setEnabled(false);
            menuNav.findItem(R.id.map_bar).setEnabled(false);
            menuNav.findItem(R.id.nfc_bar).setEnabled(false);
            menuNav.findItem(R.id.voice_bar).setEnabled(false);

            textIntro.setText("NO SE ENCUENTRA DENTRO DEL MUSEO");

        }
        else {

            menuNav.findItem(R.id.home_bar).setEnabled(true);
            menuNav.findItem(R.id.map_bar).setEnabled(true);
            menuNav.findItem(R.id.nfc_bar).setEnabled(true);
            menuNav.findItem(R.id.voice_bar).setEnabled(true);

            textIntro.setText(Double.toString(location.getLongitude()));
        }






    }


    public boolean checkLocationPermission() {

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new AlertDialog.Builder(this)
                        .setTitle(R.string.title_location_permission)
                        .setMessage(R.string.text_location_permission)
                        .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions(MainActivity.this,
                                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                        MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        })
                        .create()
                        .show();


            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
            return false;
        } else {
            return true;
        }
    }



    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // location-related task you need to do.
                    if (ContextCompat.checkSelfPermission(this,
                            Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {

                        Log.d("Ejecutando", "Pedimos localizacion");


                        //Request location updates:
                        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListener);
                    }

                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.

                }
                return;
            }

        }
    }











    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.voice_bar) {
            fragment_transaction = getSupportFragmentManager().beginTransaction();
            fragment_transaction.replace(R.id.main_container, new VoiceFragment());
            fragment_transaction.commit();
            getSupportActionBar().setTitle("Voice Fragment");

        } else if (id == R.id.home_bar) {
            fragment_transaction = getSupportFragmentManager().beginTransaction();
            fragment_transaction.replace(R.id.main_container, new HomeFragment());
            fragment_transaction.commit();
            getSupportActionBar().setTitle("Home Fragment");

        } else if (id == R.id.map_bar) {
            fragment_transaction = getSupportFragmentManager().beginTransaction();
            fragment_transaction.replace(R.id.main_container, new MapFragment());
            fragment_transaction.commit();
            getSupportActionBar().setTitle("Map Fragment");
        } else if (id == R.id.nfc_bar) {

            fragment_transaction = getSupportFragmentManager().beginTransaction();
            fragment_transaction.replace(R.id.main_container, new NFCFragment());
            fragment_transaction.commit();
            getSupportActionBar().setTitle("NFC Fragment");

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {

        menu.getItem(0).setEnabled(false); // here pass the index of save menu item


        Log.d("Ejecutando", (menu.getItem(0).getTitle().toString()));
        return super.onPrepareOptionsMenu(menu);


    }
}
